# PFX Website

Phila Forex Trading (PFX) ERC-20 website.

## Files
- index.html
- style.css
- script.js
- logo.png (put your PFX logo here)

## Before publishing
Open `script.js` and replace:
`YOUR_SEPOLIA_CONTRACT_ADDRESS`
with your real PFX Sepolia contract address.

Then the Etherscan button and MetaMask button will use the real contract.

## GitHub Pages
1. Create a GitHub repository.
2. Upload all files.
3. Put `logo.png` in the same folder as `index.html`.
4. GitHub repository → Settings → Pages.
5. Select Deploy from branch → main → /(root) → Save.

const CONTRACT = "YOUR_SEPOLIA_CONTRACT_ADDRESS";
const TOKEN_SYMBOL = "PFX";
const TOKEN_DECIMALS = 18;

const contractEl = document.getElementById("contractAddress");
const etherscanEl = document.getElementById("etherscanLink");
const messageEl = document.getElementById("walletMessage");

if (CONTRACT !== "YOUR_SEPOLIA_CONTRACT_ADDRESS") {
  contractEl.textContent = CONTRACT;
  etherscanEl.href = `https://sepolia.etherscan.io/token/${CONTRACT}`;
}

document.getElementById("copyAddress").addEventListener("click", async () => {
  const value = contractEl.textContent;
  if (value.startsWith("YOUR_")) return alert("First add your PFX contract address in script.js.");
  await navigator.clipboard.writeText(value);
  alert("Contract address copied!");
});

async function addPFX() {
  if (!window.ethereum) {
    messageEl.textContent = "MetaMask is not installed. Please install MetaMask first.";
    return;
  }
  if (CONTRACT === "YOUR_SEPOLIA_CONTRACT_ADDRESS") {
    messageEl.textContent = "Add your real PFX contract address to script.js first.";
    return;
  }
  try {
    await window.ethereum.request({
      method: "wallet_watchAsset",
      params: {
        type: "ERC20",
        options: {
          address: CONTRACT,
          symbol: TOKEN_SYMBOL,
          decimals: TOKEN_DECIMALS,
          image: new URL("logo.png", window.location.href).href
        }
      }
    });
    messageEl.textContent = "PFX token added to MetaMask.";
  } catch (error) {
    messageEl.textContent = "MetaMask request was cancelled or failed.";
  }
}
document.getElementById("addToken").addEventListener("click", addPFX);
document.getElementById("addToken2").addEventListener("click", addPFX);

document.getElementById("menuBtn").addEventListener("click", () => {
  document.getElementById("nav").classList.toggle("open");
});
document.querySelectorAll("nav a").forEach(a => a.addEventListener("click", () => {
  document.getElementById("nav").classList.remove("open");
}));
